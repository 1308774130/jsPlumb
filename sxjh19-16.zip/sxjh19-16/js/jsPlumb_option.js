jsPlumb.importDefaults({
	ConnectionsDetachable: true,
	DoNotThrowErrors:true,
	ReattachConnections:true
})
var jsPlumbData = [];
jsPlumb.ready(function() {
//	$('.mainright .proItem').each(function(i,v){
////		jsPlumb.draggable(v,{containment: 'parent'});
//		jsPlumb.draggable(v);
//		jsPlumb.connect({
//	        source: v,
//	        target: $(v).next(),
//	    }, jsPlumbO.getCommon(i+1));
//	})
	
	jsPlumbO.initPoint($('#strartPoint'),'out');
	jsPlumbO.initPoint($('#endPoint'),'in');
	
	jsPlumb.bind('click', function (conn, originalEvent) {
	  if (window.prompt('确定删除所点击的链接吗？ 输入1确定') === '1') {
	    jsPlumb.detach(conn)
	  }
	})
	
	jsPlumb.bind("connection",function(info){
	  console.log(info);
	})
	jsPlumb.bind("connectionDrag", function(connection) {
        console.log(
                connection.id +
                "被拖拽了 "
        );
    });
    jsPlumb.bind('beforeDrop', function(){
    	var type = window.prompt('是否确定连接 0取消1确定');
    	return type*1
    })
    jsPlumb.bind('dragManager', function(d){
    	debugger
    })
})

var jsPlumbO = {
	getUuid:function(domId) {
		switch(['strartPoint','endPoint'].indexOf(domId)){
			case 0:return 'strartPoint';break;
			case 1:return 'endPoint';break;
			case -1:break;
		}
      var len = 32;//32长度
      var radix = 16;//16进制
      var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split('');
      var uuid = [], i;
      radix = radix || chars.length;
      if(len) {
        for(i = 0; i < len; i++)uuid[i] = chars[0 | Math.random() * radix];
      } else {
        var r;
        uuid[8] = uuid[13] = uuid[18] = uuid[23] = '-';
        uuid[14] = '4';
        for(i = 0; i < 36; i++) {
          if(!uuid[i]) {
            r = 0 | Math.random() * 16;
            uuid[i] = chars[(i == 19) ? (r & 0x3) | 0x8 : r];
          }
        }
      }
      return uuid.join('');
    },
	getCommon:function(=){
		var lineColor  = '#d5d5d5',label={text:'',cssName:'defaultLabel'};
		switch(parseInt(typeCode)){
			case 1:
				lineColor = '#b6c5ff';label = {text:'成功',cssName:'successLabel'};break;
			case 2:
				label = {text:'失败',cssName:'errorLabel'};break;
			default:break;
		}
		var arrowOverlays = ['Arrow',{fill:lineColor,width: 11,length:10,location:1,foldback:1,id:"arrow"}];
		var labelOverlays = ["Label",{label:label.text,location:0.8,cssClass:label.cssName,events: {
                            click: function(_labelOverlay,_originalEvent) {
                                alert("看控制台");
                                console.log(_labelOverlay);
                                console.log(_originalEvent)
                            }
                        }}]
		var common = {
//			anchor: "Continuous",
//			isSource:'true',
//			isTarget:'true',//开启连接功能
			maxConnections:-1,
			allowLoopback: false,//禁止回环
			connector:['Flowchart',{gap:[5,3],stub:50,alwaysRespectStubs:'true',midpoint:0.2,cornerRadius:10}],//链接线
//			anchor: ['Continuous',{faces:["left","right"]}],//锚点位置
			connectorStyle: { outlineStroke: lineColor, strokeWidth: 0.5},
			paintStyle: { stroke: lineColor, strokeWidth: 0.5}, //连接线
			connectorOverlays: [labelOverlays,arrowOverlays,["Custom", {
			    create:function(component) {
			      return $("<select id='myDropDown'><option value='foo'>foo</option><option value='bar'>bar</option></select>");
			    },
			    location:0.7,
			    id:"customOverlay"
		  	}]],//线上的描述和断点
			endpoint:'Dot',
			endpointStyle: {
				stroke: lineColor,
                fill: "white",
                radius: 3,
                strokeWidth: 2
			},
	       hoverPaintStyle: {
	          radius:6,
	       },
		}
		return common
	},
	initPoint:function(dom,type){
		var _uuid = jsPlumbO.getUuid($(dom).attr('id'));
		jsPlumb.draggable(dom,{containment: 'parent'});
		switch(type){
			case 'in':
				jsPlumbO.paintPoint(dom,_uuid,false);break;
			case 'out':
				jsPlumbO.paintPoint(dom,_uuid,true);break;
			default:
				jsPlumbO.paintPoint(dom,_uuid,false);
				jsPlumbO.paintPoint(dom,_uuid,true);
				break
		}
		jsPlumbData.push({
			uuId : _uuid,//节点的uuid
			domId : $(dom).attr('id'),//dom元素的id
			poinType : $(dom).data('type'),//dom元素的type
			prevId : null, //前驱的uuid
			nextId : null, //后面的uuid
			typeCode : type //默认为0,1成功2失败 连线的类型
		})
	},
	paintPoint:function(dom,_uuid,isSource){
		var type = window.prompt('输入连线的类型 0默认1成功2失败');
		jsPlumb.addEndpoint(dom,{
	        uuid:_uuid,
	        isSource:isSource,
	        isTarget:!isSource,
	        anchor:['Continuous',{faces:isSource?['bottom','right']:['top','left']}]
		},jsPlumbO.getCommon(type));
//		jsPlumb.makeSource(dom, {
//          anchor:['Continuous',{faces:['top','bottom','left','right']}],
//          uuid:_uuid
//      },jsPlumbO.getCommon(type));
//
//      // 可以进行连线的终点
//      jsPlumb.makeTarget(dom, {
//          anchor:['Continuous',{faces:['top','bottom','left','right']}],
//          uuid:_uuid
//      },jsPlumbO.getCommon(type));
	}
}

