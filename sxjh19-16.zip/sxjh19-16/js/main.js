$(function(){
	var node=[
			{
				title:{p:'通用',icon:'tongyong'},
				data:[
					{icon:'gongzuotai',p:'作业'},
					{icon:'huizongwenjian',p:'汇聚'},
					{icon:'yanshikaiguan',p:'延时器'}
				]
			},
			{
				title:{p:'文件管理',icon:'wenjianguanli'},
				data:[
					{icon:'shanchu',p:'删除文件'},
					{icon:'daimabijiao',p:'合并文件'},
					{icon:'zhongmingming',p:'重命名文件'},
					{icon:'gongzuotai',p:'创建目录'},
					{icon:'huizongwenjian',p:'删除目录'},
					{icon:'yanshikaiguan',p:'移动文件'},
				]
			},
			{
				title:{p:'条件',icon:'tiaojian'},
				data:[
					{icon:'gongzuotai',p:'空目录检测'},
					{icon:'huizongwenjian',p:'文件检测'},
					{icon:'yanshikaiguan',p:'ping主机'},
					{icon:'gongzuotai',p:'检测FTP'},
				]
			},
			{
				title:{p:'脚本',icon:'jiaoben'},
				data:[
					{icon:'gongzuotai',p:'shell'},
					{icon:'huizongwenjian',p:'SQL'},
					{icon:'yanshikaiguan',p:'Hive'},
				]
			},
			{
				title:{p:'SQL',icon:'SQLsvg'},
				data:[
					{icon:'gongzuotai',p:'重命名文件'},
					{icon:'huizongwenjian',p:'创建目录'},
				]
			},
			{
				title:{p:'文件传输',icon:'wenjianchuanshu'},
				data:[
					{icon:'gongzuotai',p:'获得FTP上文件'},
					{icon:'huizongwenjian',p:'上传文件至FTP'},
					{icon:'gongzuotai',p:'删除FTP上文件'},
					{icon:'huizongwenjian',p:'比较FTP上文件'},
					{icon:'gongzuotai',p:'获得FTP上目录'},
				]
			}
		]
	
	$.each(node,function(i,v){
		var str = '<div class="item_main up">'
		str += '<div class="toolTitle"><i class="iconfont icon-'+ v.title.icon +' titleIcon"></i>'
		str += '<p>' + v.title.p + '</p>';
		str += '<i class="iconfont icon-xiala operationIcon"></i></div>';
		
		str += '<div class="toolItems"><div class="tools layui-row">'
		$.each(v.data,function(inx,vv){
			str += '<div class="layui-col-md3">';
			str += '<div class="proItem proItem-type'+i+'" data-type="' + i + '">'
			str += '<div class="cenIcon"><i class="icon-' + vv.icon + ' iconfont"></i></div>'							
			str += '<p class="proTitle">' + vv.p + '</p>'								
			str += '</div></div>'
		})
		
		$('.main_group').append(str)
	})
	
	setTimeout(function(){
		drag.init();
	},500)
	//点击收起面板展开面板
	$('.main_group').on('click','.operationIcon',function(){
		var Father = $(this).parents('.item_main');
		Father.siblings().addClass('up');
		Father.removeClass('up')
	})
})
